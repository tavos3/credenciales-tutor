<?php
include ("global/sesiones.php");
$usernameSesion = $_SESSION['usuario'];
        $username = ($usernameSesion);  